#' Clamp Values Based on Bounds
#'
#' Restricts values in a vector to fall within specified lower and upper bounds.
#' Depending on the `set_NA` parameter, values outside the bounds are either
#' clamped to the nearest boundary or set to `NA`.
#'
#' @param v Numeric vector of values to be clamped or filtered.
#' @param lo_v Numeric scalar specifying the lower bound. Values below this
#'   threshold will be clamped or set to `NA`.
#' @param up_v Numeric scalar specifying the upper bound. Values above this
#'   threshold will be clamped or set to `NA`.
#' @param set_NA Logical; if `FALSE` (default), values are clamped to the
#'   nearest bound. If `TRUE`, values outside `[lo_v, up_v]` are set to `NA`.
#'
#' @return A numeric vector of the same length as `v`, with values either
#'   clamped to the bounds or set to `NA` for out-of-range values.
#'
#' @keywords internal
clamp <- function(v, lo_v, up_v, set_NA = FALSE) {
  if (!set_NA) {
    clamped_v <- pmin(pmax(v, lo_v), up_v)
  } else {
    clamped_v <- v
    clamped_v[v < lo_v | v > up_v] <- NA
  }

  return(clamped_v)
}

#' Generate Adaptive Axis Breaks
#'
#' Creates adaptive axis breaks that extend slightly beyond the data range
#' with a reasonable number of tick locations.
#'
#' @param x Numeric vector of values to create breaks for.
#' @param n_ticks Numeric vector of length 2 specifying the range for number
#'   of ticks.
#'
#' @return A list with two components:
#'   \item{breaks}{Numeric vector of major break locations.}
#'   \item{minor_breaks}{Numeric vector of minor break locations.}
#'
#' @keywords internal
generate_adaptive_breaks <- function(x, n_ticks) {
  x_range <- range(x, na.rm = TRUE)
  x_min <- x_range[1]
  x_max <- x_range[2]

  # Calculate a reasonable step size
  raw_step <- (x_max - x_min) / mean(n_ticks)

  # Round to a "nice" number (1, 2, 5, 10, 20, 50, etc.)
  magnitude <- 10^floor(log10(raw_step))
  normalized <- raw_step / magnitude

  if (is.na(normalized) || is.nan(normalized) || is.infinite(normalized)) {
    # Handle edge case - let ggplot2 decide
    return(list(
      breaks = ggplot2::waiver(),
      minor_breaks = ggplot2::waiver()
    ))
  }

  nice_step <- magnitude *
    if (normalized < 1.5) {
      1
    } else if (normalized < 3.5) {
      2
    } else if (normalized < 7.5) {
      5
    } else {
      10
    }

  # Extend limits slightly (5% padding)
  padding <- 0.05 * (x_max - x_min)

  # Generate breaks
  break_min <- floor((x_min - padding) / nice_step) * nice_step
  break_max <- ceiling((x_max + padding) / nice_step) * nice_step

  list(
    breaks = seq(break_min, break_max, by = nice_step),
    minor_breaks = seq(break_min, break_max, by = nice_step / 2)
  )
}
