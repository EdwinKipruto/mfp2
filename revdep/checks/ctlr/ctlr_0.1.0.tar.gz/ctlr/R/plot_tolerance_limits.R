#' Generate Tolerance Limits Plot
#'
#' Creates a scatter plot showing differences between two methods with
#' tolerance limit boundaries. Points within the clinical tolerance limits
#' are displayed in green, while points outside are displayed in red.
#'
#' @param BLUP_x Numeric vector of Best Linear Unbiased Predictor (BLUP)
#'   estimates of the true latent trait.
#' @param difference Numeric vector of differences between the two methods (y1 - y2).
#' @param CTLlo Numeric vector specifying the lower clinical tolerance limit.
#' @param CTLup Numeric vector specifying the upper clinical tolerance limit.
#' @param intercept Numeric scalar for the intercept of tolerance limits.
#' @param slope Numeric scalar for the slope of tolerance limits.
#' @param within_limits Logical vector indicating whether each observation falls
#'   within the tolerance limits.
#' @param display Logical; if `TRUE`, the plot is displayed in the current graphics
#'   device. Default is `TRUE`.
#' @param export_pdf Logical; if `TRUE`, exports the plot as a PDF file named
#'   'tl_plot.pdf' to the specified path. Default is `FALSE`.
#' @param plot_path Character string specifying the directory path for PDF export.
#' @param vertical_ticks Numeric vector of length 2 specifying the range for the
#'   number of ticks on the y-axis (difference). Default is `c(5, 7)`.
#' @param horizontal_ticks Numeric vector of length 2 specifying the range for
#'   the number of ticks on the x-axis (true latent trait). Default is `c(5, 10)`.
#' @param font_size Numeric scalar specifying the base font size for plot text
#'   elements in points. Default is `14`. Title, axis labels, and other text
#'   elements are scaled relative to this base font size.
#'
#' @return Invisibly returns a ggplot object. The plot is optionally saved as
#'   'tl_plot.pdf' in the specified directory if `export_pdf = TRUE`.
#'
#' @keywords internal
plot_tolerance_limits <- function(
  BLUP_x,
  difference,
  CTLlo,
  CTLup,
  intercept,
  slope,
  within_limits,
  display = TRUE,
  export_pdf = FALSE,
  plot_path = NULL,
  vertical_ticks = c(5, 7),
  horizontal_ticks = c(5, 10),
  font_size = 14
) {
  message("\nGenerating Tolerance Limits Plot\n")
  message("**************************************************************\n")

  # Prepare data for plotting
  plot_data <- data.frame(
    difference = difference,
    BLUP_x = BLUP_x,
    within = within_limits
  )

  # Generate adaptive breaks for both axes
  x_axis <- generate_adaptive_breaks(BLUP_x, n_ticks = horizontal_ticks)
  y_axis <- generate_adaptive_breaks(difference, n_ticks = vertical_ticks)

  # Create base plot
  p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = BLUP_x, y = difference)) +
    ggplot2::geom_point(
      data = subset(plot_data, within == TRUE),
      ggplot2::aes(color = "within"),
      size = 2
    ) +
    ggplot2::geom_point(
      data = subset(plot_data, within == FALSE),
      ggplot2::aes(color = "outside"),
      shape = 1,
      size = 2
    ) +
    ggplot2::geom_line(
      ggplot2::aes(y = CTLlo, linetype = "boundary"),
      color = "seagreen"
    ) +
    ggplot2::geom_line(
      ggplot2::aes(y = CTLup, linetype = "boundary"),
      color = "seagreen"
    ) +
    ggplot2::scale_x_continuous(
      breaks = x_axis$breaks,
      minor_breaks = x_axis$minor_breaks
    ) +
    ggplot2::scale_y_continuous(
      breaks = y_axis$breaks,
      minor_breaks = y_axis$minor_breaks
    ) +
    ggplot2::scale_color_manual(
      name = "",
      values = c(within = "seagreen", outside = "red"),
      labels = c(within = "within limits", outside = "outside limits")
    ) +
    ggplot2::scale_linetype_manual(
      name = "",
      values = c(boundary = "dashed"),
      labels = "tolerance boundaries"
    ) +
    ggplot2::labs(
      title = "Tolerance Limits Plot",
      subtitle = paste0(
        "CTL = \u00b1 ",
        intercept,
        " \u00b1 True latent trait * ",
        slope
      ),
      x = "True latent trait",
      y = "Difference: y1-y2"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      legend.position = "bottom",
      plot.title = ggplot2::element_text(hjust = 0.5, size = font_size * 1.5),
      plot.subtitle = ggplot2::element_text(hjust = 0.5, size = font_size),
      axis.title = ggplot2::element_text(size = font_size * 1.1),
      axis.text = ggplot2::element_text(size = font_size * 1.1),
      legend.text = ggplot2::element_text(size = font_size * 1.1),
      legend.title = ggplot2::element_text(size = font_size * 1.1)
    )

  # Export PDF if requested
  if (export_pdf) {
    pdf_file <- file.path(plot_path, "tl_plot.pdf")
    ggplot2::ggsave(pdf_file, plot = p, device = "pdf")
    message("Tolerance limits plot exported to ", pdf_file)
  }

  if (display) {
    print(p)
  }

  return(invisible(p))
}
