#' Generate Conditional Probability of Agreement Plot
#'
#' Creates a visualization of the conditional probability of agreement between
#' two measurement methods as a function of the true latent trait. The function
#' estimates agreement probabilities, computes their variances using the delta
#' method, performs Monte Carlo simulations to construct confidence bands, and
#' generates a plot with optional pointwise and/or simultaneous confidence intervals.
#'
#' @param idvar Numeric or character vector of individual identifiers.
#' @param BLUP_x Numeric vector of Best Linear Unbiased Predictor (BLUP)
#'   estimates of the true latent trait.
#' @param V_BLUP_x Numeric vector of variances for BLUP_x estimates.
#' @param SD_BLUP_x Numeric vector of standard deviations for BLUP_x estimates.
#' @param theta2_1e Numeric scalar for slope parameter of y2 residual variance.
#' @param theta2_0e Numeric scalar for intercept parameter of y2 residual variance.
#' @param Vtheta2_1e Numeric scalar for variance of theta2_1e.
#' @param Vtheta2_0e Numeric scalar for variance of theta2_0e.
#' @param COVtheta2e Numeric scalar for covariance between theta2_0e and theta2_1e.
#' @param sig2_res_y2 Numeric vector of residual variances for the reference
#'   method (y2).
#' @param differential_bias Numeric scalar representing the differential bias
#'   estimate between the two methods.
#' @param proportional_bias Numeric scalar representing the proportional bias
#'   estimate between the two methods.
#' @param Vproportional_bias Numeric scalar for variance of proportional bias estimate.
#' @param Vdifferential_bias Numeric scalar for variance of differential bias estimate.
#' @param COVbias Numeric scalar for covariance between differential and proportional bias.
#' @param theta1_1e Numeric scalar for slope parameter of y1 residual variance.
#' @param theta1_0e Numeric scalar for intercept parameter of y1 residual variance.
#' @param Vtheta1_1e Numeric scalar for variance of theta1_1e.
#' @param Vtheta1_0e Numeric scalar for variance of theta1_0e.
#' @param COVtheta1e Numeric scalar for covariance between theta1_0e and theta1_1e.
#' @param sig2_res_y1 Numeric vector of residual variances for the new method (y1).
#' @param CTLlo Numeric vector specifying the lower clinical tolerance limit.
#' @param CTLup Numeric vector specifying the upper clinical tolerance limit.
#' @param intercept Numeric scalar for the intercept of tolerance limits.
#' @param slope Numeric scalar for the slope of tolerance limits.
#' @param nbsimul Integer specifying the number of Monte Carlo simulations to perform
#'   for constructing confidence bands.
#' @param overall_agreement Numeric scalar for overall agreement probability, or
#'   `NULL` if not available. If provided, displayed in the plot subtitle.
#' @param overall_agreement_lo Numeric scalar for lower bound of overall agreement
#'   95% CI, or `NULL` if not available.
#' @param overall_agreement_up Numeric scalar for upper bound of overall agreement
#'   95% CI, or `NULL` if not available.
#' @param pointwise_ci Logical; if `TRUE`, compute pointwise confidence bands.
#'   Default is `FALSE`.
#' @param simultaneous_ci Logical; if `TRUE`, compute simultaneous confidence bands.
#'   Default is `FALSE`.
#' @param display Logical; if `TRUE`, the plot is displayed in the current graphics
#'   device. Default is `TRUE`.
#' @param export_pdf Logical; if `TRUE`, exports the plot as a PDF file to the
#'   specified path. Default is `FALSE`.
#' @param plot_path Character string specifying the directory path for PDF export.
#' @param horizontal_ticks Numeric vector of length 2 specifying the range for
#'   the number of ticks on the x-axis (true latent trait). Default is `c(5, 10)`.
#' @param font_size Numeric scalar specifying the base font size for plot text
#'   elements in points. Default is `14`. Title, axis labels, and other text
#'   elements are scaled relative to this base font size.
#'
#' @return A list with three components:
#'   \item{Agreement}{Numeric vector of agreement probabilities for each observation.}
#'   \item{ci_bounds}{A list containing confidence interval bounds, whose structure
#'     depends on the combination of `pointwise_ci` and `simultaneous_ci` (see Details).}
#'   \item{ci_type}{Integer indicating which confidence bounds were computed:
#'     0 (both), 1 (pointwise only), or 2 (simultaneous only).}
#'
#' @details
#' The function determines which confidence bands to compute based on the values of
#' `pointwise_ci` and `simultaneous_ci`:
#' \itemize{
#'   \item If both are `TRUE` or both are `FALSE`, both types are computed (`ci_type = 0`).
#'   \item If only `pointwise_ci` is `TRUE`, only pointwise bands are computed (`ci_type = 1`).
#'   \item If only `simultaneous_ci` is `TRUE`, only simultaneous bands are computed (`ci_type = 2`).
#' }
#'
#' The `ci_bounds` component structure matches the `ci_type`:
#' \describe{
#'   \item{ci_type = 0}{Contains `lo_Agreement`, `up_Agreement`, `lo_Agreement_sim`,
#'     and `up_Agreement_sim`.}
#'   \item{ci_type = 1}{Contains `lo_Agreement` and `up_Agreement` only.}
#'   \item{ci_type = 2}{Contains `lo_Agreement_sim` and `up_Agreement_sim` only.}
#' }
#'
#' @references
#' Taffé P. (2019) "Assessing bias, precision, and agreement in method comparison studies"
#' Statistical Methods in Medical Research, 29, Number 3, pp. 778-796.
#' \doi{10.1177/0962280219844535}
#'
#' @keywords internal
plot_condProb_agreement <- function(
  idvar,
  BLUP_x,
  V_BLUP_x,
  SD_BLUP_x,
  theta2_1e,
  theta2_0e,
  Vtheta2_1e,
  Vtheta2_0e,
  COVtheta2e,
  sig2_res_y2,
  differential_bias,
  proportional_bias,
  Vproportional_bias,
  Vdifferential_bias,
  COVbias,
  theta1_1e,
  theta1_0e,
  Vtheta1_1e,
  Vtheta1_0e,
  COVtheta1e,
  sig2_res_y1,
  CTLlo,
  CTLup,
  intercept,
  slope,
  nbsimul,
  overall_agreement = NULL,
  overall_agreement_lo = NULL,
  overall_agreement_up = NULL,
  pointwise_ci = FALSE,
  simultaneous_ci = FALSE,
  display = TRUE,
  export_pdf = FALSE,
  plot_path = NULL,
  horizontal_ticks = c(5, 10),
  font_size = 14
) {
  message("\nGenerating Conditional probability of agreement plot\n")
  message("**************************************************************\n")

  # estimate agreement
  agreement_estimates <- estimate_agreement(
    CTLlo = CTLlo,
    CTLup = CTLup,
    differential_bias = differential_bias,
    proportional_bias = proportional_bias,
    BLUP_x = BLUP_x,
    sig2_res_y2 = sig2_res_y2,
    sig2_res_y1 = sig2_res_y1
  )

  Agreement <- agreement_estimates$Agreement
  logit_Agreement <- agreement_estimates$logit_Agreement
  z_up <- agreement_estimates$z_up
  z_lo <- agreement_estimates$z_lo
  diffs_mean <- agreement_estimates$diffs_mean
  diffs_var <- agreement_estimates$diffs_var

  # estimate variance of agreement with delta method
  agreement_variances <- estimate_agreement_variance(
    CTLlo = CTLlo,
    CTLup = CTLup,
    BLUP_x = BLUP_x,
    V_BLUP_x = V_BLUP_x,
    z_lo = z_lo,
    z_up = z_up,
    differential_bias = differential_bias,
    proportional_bias = proportional_bias,
    diffs_mean = diffs_mean,
    diffs_var = diffs_var,
    sig_res_y2 = sqrt(sig2_res_y2),
    sig_res_y1 = sqrt(sig2_res_y1),
    Agreement = Agreement,
    Vdifferential_bias = Vdifferential_bias,
    Vproportional_bias = Vproportional_bias,
    COVbias = COVbias,
    Vtheta2_0e = Vtheta2_0e,
    Vtheta2_1e = Vtheta2_1e,
    COVtheta2e = COVtheta2e,
    Vtheta1_0e = Vtheta1_0e,
    Vtheta1_1e = Vtheta1_1e,
    COVtheta1e = COVtheta1e,
    theta2_1e = theta2_1e,
    theta1_1e = theta1_1e
  )

  # Setup matrices for simulations
  bias_mean <- c(proportional_bias, differential_bias)
  bias_vcov <- matrix(
    c(Vproportional_bias, COVbias, COVbias, Vdifferential_bias),
    nrow = 2,
    byrow = TRUE
  )

  theta2_mean <- c(theta2_0e, theta2_1e)
  theta2_vcov <- matrix(
    c(Vtheta2_0e, COVtheta2e, COVtheta2e, Vtheta2_1e),
    nrow = 2,
    byrow = TRUE
  )

  theta1_mean <- c(theta1_0e, theta1_1e)
  theta1_vcov <- matrix(
    c(Vtheta1_0e, COVtheta1e, COVtheta1e, Vtheta1_1e),
    nrow = 2,
    byrow = TRUE
  )

  if (!xor(pointwise_ci, simultaneous_ci)) {
    ci_type <- 0
  } else if (pointwise_ci) {
    ci_type <- 1
  } else if (simultaneous_ci) {
    ci_type <- 2
  }

  ci_bounds <- simulate_agreement_ci(
    idvar = idvar,
    BLUP_x = BLUP_x,
    V_BLUP_x = V_BLUP_x,
    SD_BLUP_x = SD_BLUP_x,
    bias_mean = bias_mean,
    bias_vcov = bias_vcov,
    theta2_mean = theta2_mean,
    theta2_vcov = theta2_vcov,
    theta1_mean = theta1_mean,
    theta1_vcov = theta1_vcov,
    CTLlo = CTLlo,
    CTLup = CTLup,
    logit_Agreement = logit_Agreement,
    Vdifferential_bias = Vdifferential_bias,
    Vproportional_bias = Vproportional_bias,
    COVbias = COVbias,
    Vtheta2_0e = Vtheta2_0e,
    Vtheta2_1e = Vtheta2_1e,
    COVtheta2e = COVtheta2e,
    Vtheta1_0e = Vtheta1_0e,
    Vtheta1_1e = Vtheta1_1e,
    COVtheta1e = COVtheta1e,
    theta2_1e = theta2_1e,
    theta1_1e = theta1_1e,
    SDlogit_Agreement_BLUP = agreement_variances$SDlogit_Agreement_BLUP,
    nbsimul = nbsimul,
    ci_type = ci_type
  )

  # aggregate plotting_data with overall_agreement interval
  plotting_data <- list(
    Agreement = Agreement,
    BLUP_x = BLUP_x,
    ci_bounds = ci_bounds,
    overall_agreement = overall_agreement,
    overall_agreement_lo = overall_agreement_lo,
    overall_agreement_up = overall_agreement_up,
    intercept = intercept,
    slope = slope
  )

  # configure and call make_cpaplot
  make_cpaplot(
    plotting_data = plotting_data,
    ci_type = ci_type,
    display = display,
    export_pdf = export_pdf,
    plot_path = plot_path,
    horizontal_ticks = horizontal_ticks,
    font_size = font_size
  )

  return(list(
    Agreement = Agreement,
    ci_bounds = ci_bounds,
    ci_type = ci_type
  ))
}

#' Estimate Agreement Probabilities
#'
#' Calculates the conditional probability of agreement between two measurement
#' methods based on clinical tolerance limits and the distribution of
#' differences between methods.
#'
#' @param CTLlo Numeric vector specifying the lower clinical tolerance limit.
#' @param CTLup Numeric vector specifying the upper clinical tolerance limit.
#' @param BLUP_x Numeric vector of Best Linear Unbiased Predictor (BLUP)
#'   estimates of the true latent trait.
#' @param differential_bias Numeric scalar representing the differential
#'   bias estimate between the two methods.
#' @param proportional_bias Numeric scalar representing the proportional bias
#'   estimate between the two methods.
#' @param sig2_res_y2 Numeric scalar for the residuals variance of the reference
#'   method (y2).
#' @param sig2_res_y1 Numeric scalar for the residuals variance of the new
#'   method (y1).
#'
#' @return A list with six components:
#'   \item{Agreement}{Numeric vector of agreement probabilities for each observation.}
#'   \item{logit_Agreement}{Numeric vector of logit-transformed agreement
#'     probabilities.}
#'   \item{z_lo}{Numeric vector of standardized lower limits.}
#'   \item{z_up}{Numeric vector of standardized upper limits.}
#'   \item{diffs_mean}{Numeric vector of expected mean differences between
#'     methods.}
#'   \item{diffs_var}{Numeric scalar for the variance of differences.}
#'
#' @keywords internal
estimate_agreement <- function(
  CTLlo,
  CTLup,
  BLUP_x,
  differential_bias,
  proportional_bias,
  sig2_res_y2,
  sig2_res_y1
) {
  diffs_mean <- (differential_bias + (proportional_bias - 1) * BLUP_x) # Eq. 4 [1]

  diffs_var <- sig2_res_y2 + sig2_res_y1 # Eq. 20 [1]

  # upper and lower limits
  z_up <- (CTLup - diffs_mean) / sqrt(diffs_var)

  z_lo <- (CTLlo - diffs_mean) / sqrt(diffs_var)

  # Calculate agreement as difference between cumulative normal probabilities
  Agreement <- stats::pnorm(z_up) - stats::pnorm(z_lo)

  # Apply logit transformation
  Agreement[Agreement == 0.0 | Agreement == 1.0] <- NA

  logit_Agreement <- stats::qlogis(Agreement)

  # Clamp logit values to bounds coherent with Stata
  logit_Agreement <- clamp(
    logit_Agreement,
    lo_v = -5.0,
    up_v = 16, # 16.635532,
    set_NA = TRUE
  )

  return(list(
    Agreement = Agreement,
    logit_Agreement = logit_Agreement,
    z_lo = z_lo,
    z_up = z_up,
    diffs_mean = diffs_mean,
    diffs_var = diffs_var
  ))
}

#' Estimate Variance of Agreement with Delta Method
#'
#' @param CTLlo Lower clinical tolerance limit
#' @param CTLup Upper clinical tolerance limit
#' @param BLUP_x BLUP estimates of the true latent trait
#' @param V_BLUP_x Variance of BLUP_x
#' @param z_lo Lower z-score
#' @param z_up Upper z-score
#' @param differential_bias Differential bias estimate
#' @param proportional_bias Proportional bias estimate
#' @param diffs_mean Mean of differences
#' @param diffs_var Variance of differences
#' @param sig_res_y2 Standard deviation of residuals for y2
#' @param sig_res_y1 Standard deviation of residuals for y1
#' @param Agreement Agreement probability
#' @param Vdifferential_bias Variance of differential bias estimate
#' @param Vproportional_bias Variance of proportional bias estimate
#' @param COVbias Covariance between differential and proportional bias
#' @param Vtheta2_0e Variance of theta2_0e (intercept for y2 residual variance)
#' @param Vtheta2_1e Variance of theta2_1e (slope for y2 residual variance)
#' @param COVtheta2e Covariance between theta2_0e and theta2_1e
#' @param Vtheta1_0e Variance of theta1_0e (intercept for y1 residual variance)
#' @param Vtheta1_1e Variance of theta1_1e (slope for y1 residual variance)
#' @param COVtheta1e Covariance between theta1_0e and theta1_1e
#' @param theta2_1e Slope parameter for y2 residual variance
#' @param theta1_1e Slope parameter for y1 residual variance
#'
#' @return A list with variance and SD of logit_Agreement
#' @keywords internal
estimate_agreement_variance <- function(
  CTLlo,
  CTLup,
  BLUP_x,
  V_BLUP_x,
  z_lo,
  z_up,
  differential_bias,
  proportional_bias,
  diffs_mean,
  diffs_var,
  sig_res_y2,
  sig_res_y1,
  Agreement,
  Vdifferential_bias,
  Vproportional_bias,
  COVbias,
  Vtheta2_0e,
  Vtheta2_1e,
  COVtheta2e,
  Vtheta1_0e,
  Vtheta1_1e,
  COVtheta1e,
  theta2_1e,
  theta1_1e
) {
  # common terms
  sqrt_diffs_var <- sqrt(diffs_var)
  diffs_var_1.5 <- diffs_var^1.5

  # Partial derivatives using delta method
  # A: derivative with respect to differential_bias
  A <- stats::dnorm(z_up) *
    (-1 / sqrt_diffs_var) -
    stats::dnorm(z_lo) * (-1 / sqrt_diffs_var)

  # B: derivative with respect to proportional_bias
  B <- stats::dnorm(z_up) *
    (-BLUP_x / sqrt_diffs_var) -
    stats::dnorm(z_lo) * (-BLUP_x / sqrt_diffs_var)

  # C: derivative with respect to theta2_0e (via sig_res_y2)
  C <- stats::dnorm(z_up) *
    (-0.5) *
    diffs_var_1.5^(-1) *
    2 *
    sig_res_y2 *
    (CTLup - diffs_mean) -
    stats::dnorm(z_lo) *
      (-0.5) *
      diffs_var_1.5^(-1) *
      2 *
      sig_res_y2 *
      (CTLlo - diffs_mean)

  # D: derivative with respect to theta2_1e (via sig_res_y2)
  D <- stats::dnorm(z_up) *
    (-0.5) *
    diffs_var_1.5^(-1) *
    2 *
    sig_res_y2 *
    BLUP_x *
    (CTLup - diffs_mean) -
    stats::dnorm(z_lo) *
      (-0.5) *
      diffs_var_1.5^(-1) *
      2 *
      sig_res_y2 *
      BLUP_x *
      (CTLlo - diffs_mean)

  # E: derivative with respect to theta1_0e (via sig_res_y1)
  E <- stats::dnorm(z_up) *
    (-0.5) *
    diffs_var_1.5^(-1) *
    2 *
    sig_res_y1 *
    (CTLup - diffs_mean) -
    stats::dnorm(z_lo) *
      (-0.5) *
      diffs_var_1.5^(-1) *
      2 *
      sig_res_y1 *
      (CTLlo - diffs_mean)

  # F: derivative with respect to theta1_1e (via sig_res_y1)
  F <- stats::dnorm(z_up) *
    (-0.5) *
    diffs_var_1.5^(-1) *
    2 *
    sig_res_y1 *
    BLUP_x *
    (CTLup - diffs_mean) -
    stats::dnorm(z_lo) *
      (-0.5) *
      diffs_var_1.5^(-1) *
      2 *
      sig_res_y1 *
      BLUP_x *
      (CTLlo - diffs_mean)

  # Variance of Agreement (part 1): using estimated parameters
  V_Agreement_BLUP1 <-
    A^2 *
    Vdifferential_bias +
    B^2 * Vproportional_bias +
    C^2 * Vtheta2_0e +
    D^2 * Vtheta2_1e +
    E^2 * Vtheta1_0e +
    F^2 * Vtheta1_1e +
    2 * A * B * COVbias +
    2 * C * D * COVtheta2e +
    2 * E * F * COVtheta1e

  # G and H: derivatives with respect to BLUP_x
  sqrt_diffs_var_inv <- 1 / sqrt_diffs_var

  G <- stats::dnorm(z_up) *
    (-(proportional_bias - 1) *
      sqrt_diffs_var -
      (CTLup - diffs_mean) *
        0.5 *
        sqrt_diffs_var_inv *
        (2 * sig_res_y2 * theta2_1e + 2 * sig_res_y1 * theta1_1e)) *
    (1 / diffs_var)

  H <- stats::dnorm(z_lo) *
    (-(proportional_bias - 1) *
      sqrt_diffs_var -
      (CTLlo - diffs_mean) *
        0.5 *
        sqrt_diffs_var_inv *
        (2 * sig_res_y2 * theta2_1e + 2 * sig_res_y1 * theta1_1e)) *
    (1 / diffs_var)

  # Variance of Agreement (part 2): accounting for BLUP_x uncertainty
  V_Agreement_BLUP2 <- V_BLUP_x * (G - H)^2

  # Total variance of Agreement
  V_Agreement_BLUP <- V_Agreement_BLUP1 + V_Agreement_BLUP2

  # Variance of logit(Agreement) using delta method
  Vlogit_Agreement_BLUP <- (1 / (Agreement * (1 - Agreement)))^2 *
    V_Agreement_BLUP

  # Standard deviation
  SDlogit_Agreement_BLUP <- sqrt(Vlogit_Agreement_BLUP)
  # SDlogit_Agreement_BLUP <- pmax(SDlogit_Agreement_BLUP, 1e-2)

  return(list(
    V_Agreement_BLUP1 = V_Agreement_BLUP1,
    V_Agreement_BLUP2 = V_Agreement_BLUP2,
    V_Agreement_BLUP = V_Agreement_BLUP,
    Vlogit_Agreement_BLUP = Vlogit_Agreement_BLUP,
    SDlogit_Agreement_BLUP = SDlogit_Agreement_BLUP
  ))
}

#' Simulate Confidence Intervals for Agreement Probabilities
#'
#' Performs Monte Carlo simulations to generate confidence interval bounds for
#' conditional agreement probabilities. The function simulates BLUP estimates
#' and variance components, recalculates agreement for each simulation, and
#' constructs either pointwise, simultaneous, or both types of confidence bands.
#'
#' @param idvar Numeric or character vector of individual identifiers.
#' @param BLUP_x Numeric vector of Best Linear Unbiased Predictor (BLUP)
#'   estimates of the true latent trait.
#' @param V_BLUP_x Numeric vector of variances for BLUP_x estimates.
#' @param SD_BLUP_x Numeric vector of standard deviations for BLUP_x estimates.
#' @param bias_mean Numeric vector of length 2 containing mean values for
#'   proportional and differential bias (in that order).
#' @param bias_vcov Numeric 2x2 variance-covariance matrix for bias parameters.
#' @param theta2_mean Numeric vector of length 2 containing mean values for
#'   theta2_0e and theta2_1e (intercept and slope for y2 residual variance).
#' @param theta2_vcov Numeric 2x2 variance-covariance matrix for theta2 parameters.
#' @param theta1_mean Numeric vector of length 2 containing mean values for
#'   theta1_0e and theta1_1e (intercept and slope for y1 residual variance).
#' @param theta1_vcov Numeric 2x2 variance-covariance matrix for theta1 parameters.
#' @param CTLlo Numeric vector specifying the lower clinical tolerance limit.
#' @param CTLup Numeric vector specifying the upper clinical tolerance limit.
#' @param logit_Agreement Numeric vector of observed logit-transformed agreement
#'   probabilities.
#' @param Vdifferential_bias Numeric scalar for variance of differential bias estimate.
#' @param Vproportional_bias Numeric scalar for variance of proportional bias estimate.
#' @param COVbias Numeric scalar for covariance between differential and proportional bias.
#' @param Vtheta2_0e Numeric scalar for variance of theta2_0e.
#' @param Vtheta2_1e Numeric scalar for variance of theta2_1e.
#' @param COVtheta2e Numeric scalar for covariance between theta2_0e and theta2_1e.
#' @param Vtheta1_0e Numeric scalar for variance of theta1_0e.
#' @param Vtheta1_1e Numeric scalar for variance of theta1_1e.
#' @param COVtheta1e Numeric scalar for covariance between theta1_0e and theta1_1e.
#' @param theta2_1e Numeric scalar for slope parameter of y2 residual variance.
#' @param theta1_1e Numeric scalar for slope parameter of y1 residual variance.
#' @param SDlogit_Agreement_BLUP Numeric vector of standard deviations of
#'   logit-transformed agreement probabilities.
#' @param nbsimul Integer specifying the number of Monte Carlo simulations to perform.
#' @param ci_type Integer indicating which type of confidence bounds to compute:
#'   \describe{
#'     \item{0}{Both pointwise and simultaneous confidence bands.}
#'     \item{1}{Pointwise confidence bands only.}
#'     \item{2}{Simultaneous confidence bands only.}
#'   }
#'
#' @return A list containing confidence interval bounds. The structure depends
#'   on `ci_type`:
#'   \describe{
#'     \item{ci_type = 0}{Returns pointwise bounds---`lo_Agreement`, `up_Agreement`---and
#'       simulatneous bounds---`lo_Agreement_sim`, `up_Agreement_sim`.}
#'     \item{ci_type = 1}{Returns pointwise bounds `lo_Agreement` and `up_Agreement` only.}
#'     \item{ci_type = 2}{Returns simultaneous bounds `lo_Agreement_sim` and `up_Agreement_sim` only.}
#'   }
#'
#' @keywords internal
simulate_agreement_ci <- function(
  idvar,
  BLUP_x,
  V_BLUP_x,
  SD_BLUP_x,
  bias_mean,
  bias_vcov,
  theta2_mean,
  theta2_vcov,
  theta1_mean,
  theta1_vcov,
  CTLlo,
  CTLup,
  logit_Agreement,
  Vdifferential_bias,
  Vproportional_bias,
  COVbias,
  Vtheta2_0e,
  Vtheta2_1e,
  COVtheta2e,
  Vtheta1_0e,
  Vtheta1_1e,
  COVtheta1e,
  theta2_1e,
  theta1_1e,
  SDlogit_Agreement_BLUP,
  nbsimul,
  ci_type
) {
  N <- length(idvar)

  # Store results for each simulation
  logit_Agreement_sims <- matrix(NA, nrow = N, ncol = nbsimul)

  if (ci_type == 0 || ci_type == 2) {
    standardized_Agreement_sims <- matrix(NA, nrow = N, ncol = nbsimul)
  }

  for (j in seq_len(nbsimul)) {
    # simulate BLUP & thetas
    simulation_data_j <- sample_simulation_data(
      bias_mean = bias_mean,
      bias_vcov = bias_vcov,
      theta2_mean = theta2_mean,
      theta2_vcov = theta2_vcov,
      theta1_mean = theta1_mean,
      theta1_vcov = theta1_vcov,
      BLUP_x = BLUP_x,
      SD_BLUP_x = SD_BLUP_x,
      idvar = idvar
    )
    # estimate_agreement with simulated data
    agreement_estimates_j <- estimate_agreement(
      CTLlo = CTLlo,
      CTLup = CTLup,
      differential_bias = simulation_data_j$differential_bias,
      proportional_bias = simulation_data_j$proportional_bias,
      BLUP_x = simulation_data_j$BLUP_x,
      sig2_res_y2 = simulation_data_j$sig2_res_y2,
      sig2_res_y1 = simulation_data_j$sig2_res_y1
    )

    # store the logit_Agreement for this simulation
    logit_Agreement_sims[, j] <- agreement_estimates_j$logit_Agreement

    if (ci_type == 0 || ci_type == 2) {
      # estimate variance of agreement
      agreement_variances_j <- estimate_agreement_variance(
        CTLlo = CTLlo,
        CTLup = CTLup,
        BLUP_x = simulation_data_j$BLUP_x,
        V_BLUP_x = V_BLUP_x,
        z_lo = agreement_estimates_j$z_lo,
        z_up = agreement_estimates_j$z_up,
        differential_bias = simulation_data_j$differential_bias,
        proportional_bias = simulation_data_j$proportional_bias,
        diffs_mean = agreement_estimates_j$diffs_mean,
        diffs_var = agreement_estimates_j$diffs_var,
        sig_res_y2 = sqrt(simulation_data_j$sig2_res_y2),
        sig_res_y1 = sqrt(simulation_data_j$sig2_res_y1),
        Agreement = agreement_estimates_j$Agreement,
        Vdifferential_bias = Vdifferential_bias,
        Vproportional_bias = Vproportional_bias,
        COVbias = COVbias,
        Vtheta2_0e = Vtheta2_0e,
        Vtheta2_1e = Vtheta2_1e,
        COVtheta2e = COVtheta2e,
        Vtheta1_0e = Vtheta1_0e,
        Vtheta1_1e = Vtheta1_1e,
        COVtheta1e = COVtheta1e,
        theta2_1e = theta2_1e,
        theta1_1e = theta1_1e
      )

      SDlogit_Agreement_j <- agreement_variances_j$SDlogit_Agreement_BLUP

      d_j <- abs(logit_Agreement_sims[, j] - logit_Agreement) /
        SDlogit_Agreement_j

      # store the standardized_Agreement for this simulation
      standardized_Agreement_sims[, j] <- d_j
    }
  }

  logit_Agreement_sims <- cbind(idvar, logit_Agreement_sims)

  if (ci_type == 0) {
    # generate pointwise bounds
    pointwise_bounds <- make_pointwise_ci_bounds(
      BLUP_x,
      logit_Agreement,
      logit_Agreement_sims
    )
    # simulate empiricale quantile
    crit_value <- find_empirical_quantile(standardized_Agreement_sims)
    # generate simultaneous bounds
    simultaneous_bounds <- make_simultaneous_ci_bounds(
      BLUP_x = BLUP_x,
      logit_Agreement = logit_Agreement,
      SDlogit_Agreement_BLUP = SDlogit_Agreement_BLUP,
      crit_value = crit_value
    )

    ci_bounds <- list(
      lo_Agreement = pointwise_bounds$lo_Agreement,
      up_Agreement = pointwise_bounds$up_Agreement,
      lo_Agreement_sim = simultaneous_bounds$lo_Agreement_sim,
      up_Agreement_sim = simultaneous_bounds$up_Agreement_sim
    )
  } else if (ci_type == 1) {
    pointwise_bounds <- make_pointwise_ci_bounds(
      BLUP_x,
      logit_Agreement,
      logit_Agreement_sims
    )
    ci_bounds <- list(
      lo_Agreement = pointwise_bounds$lo_Agreement,
      up_Agreement = pointwise_bounds$up_Agreement
    )
  } else if (ci_type == 2) {
    # simulate empiricale quantile
    crit_value <- find_empirical_quantile(standardized_Agreement_sims)
    # generate simultaneous bounds
    simultaneous_bounds <- make_simultaneous_ci_bounds(
      BLUP_x = BLUP_x,
      logit_Agreement = logit_Agreement,
      SDlogit_Agreement_BLUP = SDlogit_Agreement_BLUP,
      crit_value = crit_value
    )

    ci_bounds <- list(
      lo_Agreement_sim = simultaneous_bounds$lo_Agreement_sim,
      up_Agreement_sim = simultaneous_bounds$up_Agreement_sim
    )
  } else {
    stop("Invalid ci_type. Must be 0, 1, or 2.")
  }

  return(ci_bounds)
}

#' Sample Data for Agreement Simulation Iterations
#'
#' Generates simulated parameter values for a single Monte Carlo iteration
#' in the agreement confidence interval estimation process. The function
#' samples BLUP estimates, bias parameters, and residual variance parameters
#' from their respective distributions, ensuring one sample per individual
#' is drawn and then replicated across all observations for that individual.
#'
#' @param bias_mean Numeric vector of length 2 containing mean values for
#'   proportional and differential bias (in that order).
#' @param bias_vcov Numeric 2x2 variance-covariance matrix for bias parameters.
#' @param theta2_mean Numeric vector of length 2 containing mean values for
#'   theta2_0e and theta2_1e (intercept and slope for y2 residual variance).
#' @param theta2_vcov Numeric 2x2 variance-covariance matrix for theta2 parameters.
#' @param theta1_mean Numeric vector of length 2 containing mean values for
#'   theta1_0e and theta1_1e (intercept and slope for y1 residual variance).
#' @param theta1_vcov Numeric 2x2 variance-covariance matrix for theta1 parameters.
#' @param BLUP_x Numeric vector of Best Linear Unbiased Predictor (BLUP)
#'   estimates of the true latent trait.
#' @param SD_BLUP_x Numeric vector of standard deviations for BLUP_x estimates.
#' @param idvar Numeric or character vector of individual identifiers.
#'
#' @return A list with five components:
#'   \item{BLUP_x}{Numeric vector of simulated BLUP values, length N.}
#'   \item{differential_bias}{Numeric vector of simulated differential bias
#'     values, length N.}
#'   \item{proportional_bias}{Numeric vector of simulated proportional bias
#'     values, length N.}
#'   \item{sig2_res_y2}{Numeric vector of simulated residual variances for
#'     the reference method (y2), length N.}
#'   \item{sig2_res_y1}{Numeric vector of simulated residual variances for
#'     the new method (y1), length N.}
#'
#' @keywords internal
sample_simulation_data <- function(
  bias_mean,
  bias_vcov,
  theta2_mean,
  theta2_vcov,
  theta1_mean,
  theta1_vcov,
  BLUP_x,
  SD_BLUP_x,
  idvar
) {
  # Get number of unique individuals
  unique_ids <- unique(idvar)
  n_individuals <- length(unique_ids)
  first_obs_mask <- !duplicated(idvar)

  # Sample BLUP_x once per individual
  BLUP_x_sampled <- stats::rnorm(
    n_individuals,
    BLUP_x[first_obs_mask],
    SD_BLUP_x[first_obs_mask]
  )

  # Assign to all observations using factor indexing
  BLUP_x_j <- BLUP_x_sampled[match(idvar, unique_ids)]

  # Sample bias parameters once per individual
  bias_params <- MASS::mvrnorm(n_individuals, mu = bias_mean, Sigma = bias_vcov)
  proportional_bias_j <- bias_params[match(idvar, unique_ids), 1]
  differential_bias_j <- bias_params[match(idvar, unique_ids), 2]

  # Sample theta2 parameters once per individual
  theta2_params <- MASS::mvrnorm(
    n_individuals,
    mu = theta2_mean,
    Sigma = theta2_vcov
  )
  theta2_0_j <- theta2_params[match(idvar, unique_ids), 1]
  theta2_1_j <- theta2_params[match(idvar, unique_ids), 2]

  # Sample theta1 parameters once per individual
  theta1_params <- MASS::mvrnorm(
    n_individuals,
    mu = theta1_mean,
    Sigma = theta1_vcov
  )
  theta1_0_j <- theta1_params[match(idvar, unique_ids), 1]
  theta1_1_j <- theta1_params[match(idvar, unique_ids), 2]

  # Compute residual standard deviations
  sig_res_y2_j <- (theta2_0_j + theta2_1_j * BLUP_x_j) * sqrt(pi / 2)
  sig_res_y1_j <- (theta1_0_j + theta1_1_j * BLUP_x_j) * sqrt(pi / 2)

  # Compute residual variances
  sig2_res_y2_j <- sig_res_y2_j^2
  sig2_res_y1_j <- sig_res_y1_j^2

  return(list(
    BLUP_x = BLUP_x_j,
    differential_bias = differential_bias_j,
    proportional_bias = proportional_bias_j,
    sig2_res_y2 = sig2_res_y2_j,
    sig2_res_y1 = sig2_res_y1_j
  ))
}

#' Find Empirical Quantile
#'
#' Computes the empirical quantile across simulations.
#'
#' @param sims Numeric matrix where rows represent observations and columns
#'   represent simulation iterations.
#' @param prob Numeric scalar specifying the desired probability level for
#'   the quantile (default is 95).
#'
#' @return A numeric scalar representing the empirical quantile at the
#'   specified probability level.
#'
#' @keywords internal
find_empirical_quantile <- function(sims, prob = 95) {
  # Find max for each simulation (column-wise max)
  max_per_sim <- apply(sims, 2, max, na.rm = TRUE)
  empirical_quantile <- stats::quantile(max_per_sim, probs = prob / 100)

  return(empirical_quantile)
}

#' Compute Pointwise Confidence Interval Bounds from Simulation Results
#'
#' Calculates pointwise 95\% confidence intervals for agreement probabilities
#' using standard deviations from simulation data. The bounds are computed on
#' the logit scale, smoothed using fractional polynomial models, and then
#' transformed back to the probability scale.
#'
#' @param BLUP_x Numeric vector of BLUP estimates of the true latent trait.
#' @param logit_Agreement Numeric vector of logit-transformed agreement
#'   probabilities.
#' @param logit_Agreement_sims Matrix where the first column contains the
#'   individual identifier (`idvar`) and remaining columns contain
#'   logit-transformed agreement values from each simulation iteration.
#'
#' @return A list with two components:
#'   \item{lo_Agreement}{Numeric vector of lower confidence bounds for
#'     agreement probabilities. Only the first observation for each unique
#'     individual is populated; remaining values are `NA`.}
#'   \item{up_Agreement}{Numeric vector of upper confidence bounds for
#'     agreement probabilities. Only the first observation for each unique
#'     individual is populated; remaining values are `NA`.}
#'
#' @keywords internal
make_pointwise_ci_bounds <- function(
  BLUP_x,
  logit_Agreement,
  logit_Agreement_sims
) {
  # Calculate SD across simulations (rowwise)
  # browser()
  SD_logit_Agreement <- rep(NA, length(logit_Agreement))
  lo_Agreement <- rep(NA, length(logit_Agreement))
  up_Agreement <- rep(NA, length(logit_Agreement))

  first_obs_mask <- !duplicated(logit_Agreement_sims[, 1])
  logit_Agreement_mask <- !is.na(logit_Agreement)
  set_values_mask <- first_obs_mask & logit_Agreement_mask

  SD_per_obs <- apply(
    X = logit_Agreement_sims[, -1],
    MARGIN = 1,
    FUN = stats::sd,
    na.rm = TRUE
  )

  # Extract only the first SD for each unique idvar

  SD_logit_Agreement[first_obs_mask] <- SD_per_obs[first_obs_mask]

  # generate pointwise bounds
  lo_logit_Agreement <- logit_Agreement - 1.96 * SD_logit_Agreement
  up_logit_Agreement <- logit_Agreement + 1.96 * SD_logit_Agreement

  # Fit fractional polynomial model with degree 2
  data_frame_fit <- data.frame(
    y = lo_logit_Agreement[first_obs_mask],
    x = BLUP_x[first_obs_mask]
  )

  data_frame_fit <- data_frame_fit[stats::complete.cases(data_frame_fit), ]

  invisible(utils::capture.output(
    lo_fit <- mfp2::mfp2(
      y ~ mfp2::fp(x, df = 4),
      data = data_frame_fit
    )
  ))

  lo_logit_Agreement_fit <- stats::predict(
    lo_fit,
    newdata = data.frame(x = BLUP_x[set_values_mask]) # predict only where the model was fit
  )

  data_frame_fit <- data.frame(
    y = up_logit_Agreement[first_obs_mask],
    x = BLUP_x[first_obs_mask]
  )

  data_frame_fit <- data_frame_fit[stats::complete.cases(data_frame_fit), ]

  invisible(utils::capture.output(
    up_fit <- mfp2::mfp2(
      y ~ mfp2::fp(x, df = 4),
      data = data_frame_fit
    )
  ))

  up_logit_Agreement_fit <- stats::predict(
    up_fit,
    newdata = data.frame(x = BLUP_x[set_values_mask]) # predict only where the model was fit
  )

  # Apply inverse logit transformation (logistic function)
  lo_Agreement[set_values_mask] <- stats::plogis(lo_logit_Agreement_fit)
  up_Agreement[set_values_mask] <- stats::plogis(up_logit_Agreement_fit)

  return(list(
    lo_Agreement = lo_Agreement,
    up_Agreement = up_Agreement
  ))
}

#' Compute Simultaneous Confidence Interval Bounds
#'
#' Calculates simultaneous 95% confidence intervals for agreement probabilities
#' using a critical value derived from simulation-based standardized logit agreements.
#' The bounds are computed on the logit scale, smoothed using fractional
#' polynomial models, and then transformed back to the probability scale.
#'
#' @param BLUP_x Numeric vector of Best Linear Unbiased Predictor (BLUP)
#'   estimates of the true latent trait.
#' @param logit_Agreement Numeric vector of logit-transformed agreement
#'   probabilities.
#' @param SDlogit_Agreement_BLUP Numeric vector of standard deviations of
#'   logit-transformed agreement probabilities.
#' @param crit_value Numeric scalar representing the critical value for
#'   simultaneous confidence bands, obtained as an empirical quantile of
#'   simulation-based standardized logit agreements (see `find_empirical_quantile()`).
#'
#' @return A list with two components:
#'   \item{lo_Agreement_sim}{Numeric vector of lower simultaneous confidence
#'     bounds for agreement probabilities.}
#'   \item{up_Agreement_sim}{Numeric vector of upper simultaneous confidence
#'     bounds for agreement probabilities.}
#'
#' @keywords internal
make_simultaneous_ci_bounds <- function(
  BLUP_x,
  logit_Agreement,
  SDlogit_Agreement_BLUP,
  crit_value
) {
  # browser()

  lo_Agreement_sim <- rep(NA, length(logit_Agreement))
  up_Agreement_sim <- rep(NA, length(logit_Agreement))

  set_values_mask <- !is.na(logit_Agreement)

  lo_logit_Agreement_sim <- logit_Agreement -
    crit_value * SDlogit_Agreement_BLUP
  up_logit_Agreement_sim <- logit_Agreement +
    crit_value * SDlogit_Agreement_BLUP

  data_frame_fit <- data.frame(y = lo_logit_Agreement_sim, x = BLUP_x)
  data_frame_fit <- data_frame_fit[stats::complete.cases(data_frame_fit), ]

  invisible(utils::capture.output(
    lo_fit <- mfp2::mfp2(
      y ~ mfp2::fp(x, df = 4),
      data = data_frame_fit
    )
  ))
  lo_logit_Agreement_sim_fit <- stats::predict(
    lo_fit,
    newdata = data.frame(x = BLUP_x[set_values_mask]) # predict only where the model was fit
  )

  data_frame_fit <- data.frame(y = up_logit_Agreement_sim, x = BLUP_x)
  data_frame_fit <- data_frame_fit[stats::complete.cases(data_frame_fit), ]

  invisible(utils::capture.output(
    up_fit <- mfp2::mfp2(
      y ~ mfp2::fp(x, df = 4),
      data = data_frame_fit
    )
  ))
  up_logit_Agreement_sim_fit <- stats::predict(
    up_fit,
    newdata = data.frame(x = BLUP_x[set_values_mask]) # predict only where the model was fit
  )

  # Apply inverse logit transformation (logistic function)
  lo_Agreement_sim[set_values_mask] <- stats::plogis(lo_logit_Agreement_sim_fit)
  up_Agreement_sim[set_values_mask] <- stats::plogis(up_logit_Agreement_sim_fit)

  return(list(
    lo_Agreement_sim = lo_Agreement_sim,
    up_Agreement_sim = up_Agreement_sim
  ))
}

#' Make Conditional Probability of Agreement Plot
#'
#' Generates a ggplot2 visualization showing the conditional probability of
#' agreement as a function of the true latent trait, with pointwise
#' and/or simultaneous confidence bands.
#'
#' @param plotting_data A list containing the following components:
#' \describe{
#'   \item{Agreement}{Numeric vector of agreement probabilities.}
#'   \item{BLUP_x}{Numeric vector of BLUP estimates of the true latent trait.}
#'   \item{ci_bounds}{A list containing confidence interval bounds (see Details).}
#'   \item{overall_agreement}{Overall agreement probability.}
#'   \item{overall_agreement_lo}{Lower bound of overall agreement 95\code{\%} CI.}
#'   \item{overall_agreement_up}{Upper bound of overall agreement 95\code{\%} CI.}
#' }
#'
#' @param ci_type Integer indicating which confidence bounds to display:
#' \describe{
#'   \item{0}{Both pointwise and simultaneous confidence bands.}
#'   \item{1}{Pointwise confidence bands only.}
#'   \item{2}{Simultaneous confidence bands only.}
#' }
#'
#' @param display Logical; if `TRUE`, the plot is printed to the current graphics
#'   device.
#' @param export_pdf Logical; if `TRUE`, exports the plot as a PDF file to the
#'   specified path.
#' @param plot_path Character string specifying the directory path for PDF export.
#'
#' @return Invisibly returns the ggplot object.
#'
#' @details
#' The `ci_bounds` component of `plotting_data` is a list produced by the function `simulate_agreement_ci`
#' and may contain:
#' \describe{
#'   \item{`lo_Agreement` and `up_Agreement`}{Pointwise lower and upper
#'     confidence bounds.}
#'   \item{`lo_Agreement_sim` and `up_Agreement_sim`}{Simultaneous lower and upper
#'     confidence bounds.}
#' }
#'
#' @keywords internal
make_cpaplot <- function(
  plotting_data,
  ci_type,
  display,
  export_pdf,
  plot_path,
  horizontal_ticks,
  font_size
) {
  Agreement <- plotting_data$Agreement
  BLUP_x <- plotting_data$BLUP_x
  overall_agreement <- plotting_data$overall_agreement
  overall_agreement_lo <- plotting_data$overall_agreement_lo
  overall_agreement_up <- plotting_data$overall_agreement_up
  intercept <- plotting_data$intercept
  slope <- plotting_data$slope

  ci_bounds <- plotting_data$ci_bounds
  x_axis <- generate_adaptive_breaks(BLUP_x, n_ticks = horizontal_ticks)

  if (ci_type == 0) {
    lo_Agreement <- ci_bounds$lo_Agreement
    up_Agreement <- ci_bounds$up_Agreement
    lo_Agreement_sim <- ci_bounds$lo_Agreement_sim
    up_Agreement_sim <- ci_bounds$up_Agreement_sim
  } else if (ci_type == 1) {
    lo_Agreement <- ci_bounds$lo_Agreement
    up_Agreement <- ci_bounds$up_Agreement
    lo_Agreement_sim <- NULL
    up_Agreement_sim <- NULL
  } else if (ci_type == 2) {
    lo_Agreement <- NULL
    up_Agreement <- NULL
    lo_Agreement_sim <- ci_bounds$lo_Agreement_sim
    up_Agreement_sim <- ci_bounds$up_Agreement_sim
  }

  # Create subtitle with overall agreement
  subtitle_text <- NULL
  if (!is.null(overall_agreement)) {
    subtitle_text <- sprintf(
      "Overall agreement: %.3f, 95%% CI=[%.3f, %.3f]",
      overall_agreement,
      overall_agreement_lo,
      overall_agreement_up
    )
  }

  # Create base plot
  p <- ggplot2::ggplot(
    data.frame(BLUP_x, Agreement),
    ggplot2::aes(x = BLUP_x, y = Agreement)
  ) +
    ggplot2::geom_point(
      ggplot2::aes(color = "Agreement", shape = "Agreement"),
      size = 2
    ) +
    ggplot2::scale_color_manual(
      name = NULL,
      values = c("Agreement" = "seagreen")
    ) +
    ggplot2::scale_shape_manual(
      name = NULL,
      values = c("Agreement" = 16)
    ) +
    ggplot2::labs(
      title = "Conditional probability of agreement plot",
      subtitle = subtitle_text,
      caption = paste0(
        "CTL = \u00b1 ",
        intercept,
        " \u00b1 True latent trait * ",
        slope
      ),
      x = "True latent trait",
      y = "Probability of agreement"
    ) +
    ggplot2::scale_y_continuous(
      limits = c(0, 1),
      breaks = seq(0, 1, 0.1),
      minor_breaks = seq(0, 1, 0.05)
    ) +
    ggplot2::scale_x_continuous(
      breaks = x_axis$breaks,
      minor_breaks = x_axis$minor_breaks
    ) +
    ggplot2::theme_minimal()

  # Add pointwise bounds if available
  if (!is.null(lo_Agreement) && !is.null(up_Agreement)) {
    plot_data <- data.frame(BLUP_x, lo_Agreement, up_Agreement)
    plot_data <- plot_data[stats::complete.cases(plot_data), ]

    p <- p +
      ggplot2::geom_line(
        data = plot_data,
        ggplot2::aes(x = BLUP_x, y = lo_Agreement, linetype = "pointwise"),
        color = "seagreen"
      ) +
      ggplot2::geom_line(
        data = plot_data,
        ggplot2::aes(x = BLUP_x, y = up_Agreement, linetype = "pointwise"),
        color = "seagreen"
      )
  }

  # Add simultaneous bounds if available
  if (!is.null(lo_Agreement_sim) && !is.null(up_Agreement_sim)) {
    p <- p +
      ggplot2::geom_line(
        data = data.frame(BLUP_x, lo_Agreement_sim),
        ggplot2::aes(
          x = BLUP_x,
          y = lo_Agreement_sim,
          linetype = "simultaneous"
        ),
        color = "orange"
      ) +
      ggplot2::geom_line(
        data = data.frame(BLUP_x, up_Agreement_sim),
        ggplot2::aes(
          x = BLUP_x,
          y = up_Agreement_sim,
          linetype = "simultaneous"
        ),
        color = "orange"
      )
  }

  # Configure legend based on what bounds are present
  if (!is.null(lo_Agreement) && !is.null(lo_Agreement_sim)) {
    # Both types present
    p <- p +
      ggplot2::scale_linetype_manual(
        name = NULL,
        values = c("pointwise" = "dashed", "simultaneous" = "dotdash"),
        labels = c(
          "pointwise" = "95% pointwise CB",
          "simultaneous" = "95% simultaneous CB"
        )
      )
  } else if (!is.null(lo_Agreement)) {
    # Only pointwise
    p <- p +
      ggplot2::scale_linetype_manual(
        name = NULL,
        values = c("pointwise" = "dashed"),
        labels = c("pointwise" = "95% pointwise CB")
      )
  } else if (!is.null(lo_Agreement_sim)) {
    # Only simultaneous
    p <- p +
      ggplot2::scale_linetype_manual(
        name = NULL,
        values = c("simultaneous" = "dotdash"),
        labels = c("simultaneous" = "95% simultaneous CB")
      )
  }

  p <- p +
    ggplot2::theme(
      legend.position = "bottom",
      plot.title = ggplot2::element_text(hjust = 0.5, size = font_size * 1.5),
      plot.subtitle = ggplot2::element_text(hjust = 0.5, size = font_size),
      plot.caption = ggplot2::element_text(hjust = 0.0, size = font_size),
      axis.title = ggplot2::element_text(size = font_size * 1.1),
      axis.text = ggplot2::element_text(size = font_size * 1.1),
      legend.text = ggplot2::element_text(size = font_size * 1.1),
      legend.title = ggplot2::element_text(size = font_size * 1.1)
    )

  # Export PDF if requested
  if (export_pdf) {
    pdf_file <- file.path(plot_path, "cpa_plot.pdf")
    ggplot2::ggsave(pdf_file, plot = p, device = "pdf")
    message(
      "Conditional probability of agreement plot exported to ",
      normalizePath(pdf_file)
    )
  }

  if (display) {
    print(p)
  }

  return(invisible(p))
}
