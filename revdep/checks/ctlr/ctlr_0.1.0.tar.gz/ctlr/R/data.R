#' ctl_dataset1
#'
#' A simulated dataset where the number of individuals is 100 and the number of repeated measurements per individual is 5 for both methods.
#'
#' @format ## `ctl_dataset1`
#' A data frame with 500 rows and 4 variables:
#' \describe{
#'   \item{id}{represents the individual}
#'   \item{t}{the index for the repeated measurements}
#'   \item{y1}{the measurements made by method 1}
#'   \item{y2}{the measurements made by method 2}
#' }
#' @source Taffé, P. (2025). "ctl: A package for assessing agreement based on clinical tolerance limits" The Stata Journal, 25, Number 3, pp. 659–676.
#' \doi{10.1177/1536867X251365501}
"ctl_dataset1"

#' ctl_dataset2
#'
#' A simulated dataset where the number of individuals is 100 and the number of repeated measurements per individual varies between 1 to 3 for method 1 and between 5 to 10 for method 2.
#'
#' @format ## `ctl_dataset2`
#' A data frame with 745 rows and 4 variables:
#' \describe{
#'   \item{id}{represents the individual}
#'   \item{t}{the index for the repeated measurements}
#'   \item{y1}{the measurements made by method 1}
#'   \item{y2}{the measurements made by method 2}
#' }
#' @source Taffé, P. (2025). "ctl: A package for assessing agreement based on clinical tolerance limits" The Stata Journal, 25, Number 3, pp. 659–676.
#' \doi{10.1177/1536867X251365501}
"ctl_dataset2"
