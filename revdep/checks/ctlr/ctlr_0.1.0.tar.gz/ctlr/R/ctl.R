# Declare global variables used in NSE contexts
utils::globalVariables(c(
  "y1",
  "y2",
  "id",
  "BLUP_x",
  "abs_res_y1",
  "abs_res_y2",
  "res_y1",
  "res_y2",
  "fit_abs_res_y1",
  "fit_abs_res_y2",
  "sig_res_y1",
  "sig_res_y2",
  "sig2_res_y1",
  "sig2_res_y2",
  "SE_BLUP",
  "V_BLUP_x",
  "SD_BLUP_x",
  "t"
))

#' Clinical Tolerance Limits for Assessing Agreement
#'
#' Assesses agreement between two measurement methods using clinical tolerance
#' limits (CTL). The function estimates the true latent trait, models bias and
#' variance components, calculates overall and conditional agreement probabilities,
#' and optionally generates tolerance limits or conditional probability of agreement plots.
#'
#' @importFrom stats predict lm coef residuals
#' @importFrom dplyr select filter group_by mutate ungroup row_number n_distinct
#' @importFrom lme4 lmer ranef
#' @importFrom sandwich vcovHC
#' @importFrom lmtest coefci
#'
#' @param data A data frame containing the measurements.
#' @param idvar Character string specifying the name of the ID variable (subject identifier).
#' @param ynew Character string specifying the name of the new method variable.
#' @param yref Character string specifying the name of the reference method variable.
#' @param intercept Numeric scalar for the intercept of tolerance limits. Default is 0.
#' @param slope Numeric scalar for the slope of tolerance limits. Default is 0.
#' @param nbsimul Integer specifying the number of Monte Carlo simulations for
#'   confidence bands. Default is 1000.
#' @param seed Integer specifying the random seed for reproducibility. Default is 123456789.
#' @param tlplot Logical; if `TRUE`, generates a tolerance limits plot. Default is `FALSE`.
#' @param cpaplot Logical; if `TRUE`, generates a conditional probability of
#'   agreement (CPA) plot. Default is `FALSE`.
#' @param pointwise Logical; if `TRUE`, includes pointwise confidence bands in
#'   the CPA plot. Default is `FALSE`.
#' @param simultaneous Logical; if `TRUE`, includes simultaneous confidence bands
#'   in the CPA plot. Default is `FALSE`.
#' @param plots_to_file Logical; if `TRUE`, exports generated plots as PDF files to the
#'   "ctl_outputs/" directory. Default is `FALSE`.
#' @param results_to_file Logical; if `TRUE`, saves the results dataset to
#'   "ctl_outputs/ctl_results.rda". Default is `FALSE`.
#' @param outputs_path Character string specifying the directory path where an
#'   "ctl_outputs" directory can be created to store the results' file and/or the plots,
#'   as required by `plots_to_file` and `results_to_file` arguments.
#'   Default is `NULL` and causes an error message if one of `plots_to_file`
#'   or `results_to_file` is `TRUE`.
#' @param horizontal_ticks Numeric vector of length 2 specifying the range for
#'   the number of ticks on the x-axis (true latent trait). Default is `c(5, 10)`.
#' @param vertical_ticks Numeric vector of length 2 specifying the range for the
#'   number of ticks on the y-axis. Only relevant for tlplot. Default is `c(5, 7)`.
#' @param font_size Numeric scalar specifying the base font size for plot text
#'   elements in points. Default is `14`. Title, axis labels, and other text
#'   elements are scaled relative to this base font size.
#'
#' @return Invisibly returns `ctl_results`. The function is called for:
#'   printing results to the console, generating plots, and optionally saving
#'   results and plots to files.
#'   Console messages are suppressable with `suppressMessages()`.
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Estimates Best Linear Unbiased Predictors (BLUP) for the true latent
#'     trait using the reference method with a linear mixed model.
#'   \item Models residual variance for the reference method (y2) as a function
#'     of the latent trait.
#'   \item Estimates differential and proportional bias between methods using
#'     heteroscedasticity-consistent standard errors.
#'   \item Models residual variance for the new method as a function of
#'     the latent trait.
#'   \item Calculates overall agreement as the proportion of observations falling
#'     within the clinical tolerance limits, with 95% confidence intervals using
#'     the Agresti-Coull method.
#'   \item Optionally generates tolerance limits plots and/or conditional
#'     probability of agreement plots with confidence bands.
#' }
#'
#' The function creates a "ctl_outputs" directory at the specified `outputs_path`
#' to store generated plots and results when requested.
#'
#' When `cpaplot = TRUE` and `results = TRUE`, the saved dataset includes
#' agreement probabilities and confidence bounds. The structure depends on
#' the `pointwise` and `simultaneous` arguments.
#'
#' @references
#' Taffé P. (2016) "Effective plots to assess bias and precision in method
#' comparison studies" Statistical Methods in Medical Research, 27, Number 6,
#' pp. 1650-1660.
#' \doi{10.1177/0962280216666667}
#'
#' Taffé P. (2019) "Assessing bias, precision, and agreement in method comparison
#' studies" Statistical Methods in Medical Research, 29, Number 3, pp. 778-796.
#' \doi{10.1177/0962280219844535}
#'
#' Taffé, P. (2025). "ctl: A package for assessing agreement based on clinical
#' tolerance limits" The Stata Journal, 25, Number 3, pp. 659–676.
#' \doi{10.1177/1536867X251365501}
#'
#' @examplesIf requireNamespace("withr", quietly = TRUE)
#' withr::with_tempdir({
#'    # Tolerance limit plot
#'    ctl(ctl_dataset1, idvar = "id", ynew = "y1", yref = "y2", intercept = 5, slope = 0.15,
#'        tlplot = TRUE, plots_to_file = TRUE, results_to_file = TRUE, outputs_path = ".")
#'
#'    ctl(ctl_dataset2, idvar = "id", ynew = "y1", yref = "y2", intercept = 1, slope = 0.2,
#'        seed = 11446158, tlplot = TRUE, plots_to_file = TRUE, results_to_file = TRUE,
#'        outputs_path = ".")
#'
#'    # Conditional probability of agreement plot
#'    ctl(ctl_dataset1, idvar = "id", ynew = "y1", yref = "y2", intercept = 5, slope = 0.15,
#'        nbsimul = 100, cpaplot = TRUE, plots_to_file = TRUE, results_to_file = TRUE,
#'        outputs_path = ".")
#'
#'    ctl(ctl_dataset1, idvar = "id", ynew = "y1", yref = "y2", intercept = 0, slope = 0.15,
#'        nbsimul = 100, cpaplot = TRUE, pointwise = TRUE, plots_to_file = TRUE,
#'        results_to_file = TRUE, outputs_path = ".")
#'
#'    ctl(ctl_dataset2, idvar = "id", ynew = "y1", yref = "y2", intercept = 1, slope = 0.2,
#'        seed = 11446158, nbsimul = 100, cpaplot = TRUE, simultaneous = TRUE)
#' })
#'
#' @export

ctl <- function(
  data,
  idvar,
  ynew,
  yref,
  intercept = 0,
  slope = 0,
  nbsimul = 1000L,
  seed = 123456789L,
  tlplot = FALSE,
  cpaplot = FALSE,
  pointwise = FALSE,
  simultaneous = FALSE,
  plots_to_file = FALSE,
  results_to_file = FALSE,
  outputs_path = NULL,
  horizontal_ticks = c(5, 10),
  vertical_ticks = c(5, 7),
  font_size = 14
) {
  set.seed(seed)

  if (plots_to_file || results_to_file) {
    if (is.null(outputs_path)) {
      stop(
        "Please provide the `outputs_path` argument in `ctl()` where a `ctl_outputs` directory can be created to store results and/or plots ..."
      )
    } else {
      outputs_dir <- file.path(outputs_path, "ctl_outputs")
      if (!dir.exists(outputs_dir)) {
        dir.create(outputs_dir, recursive = TRUE)
      }
    }
  }

  message("\nUse of Clinical Tolerance Limits (CTL) for assessing agreement")
  message("**************************************************************\n")
  message("ID Variable: ", idvar)
  message("New Method Y Variable: ", ynew)
  message("Reference Method Y Variable: ", yref)
  message("Running...\n")

  message("seed set to ", seed, "\n")

  if (slope != 0) {
    message(
      "Non-constant tolerance limits specified: intercept= ",
      intercept,
      "& slope= ",
      slope,
      "\n"
    )
  } else {
    message(
      "Constant tolerance limits specified: intercept= ",
      intercept,
      "& slope= ",
      slope,
      "\n"
    )
  }

  # Prepare data
  dat <- data |>
    dplyr::select(id = {{ idvar }}, y1 = {{ ynew }}, y2 = {{ yref }}) |>
    dplyr::filter(!is.na(y1) | !is.na(y2)) |>
    dplyr::group_by(id) |>
    dplyr::mutate(t = dplyr::row_number()) |>
    dplyr::ungroup()

  nb_ind <- dplyr::n_distinct(dat$id)

  # Step 1: Estimate BLUP for true latent trait (x) using reference method
  message("Estimating BLUP for latent trait...")
  model_blup <- lme4::lmer(y2 ~ 1 + (1 | id), data = dat, REML = TRUE)

  complete_idx <- !is.na(dat$y2)
  dat$BLUP_x <- NA_real_

  dat$BLUP_x[complete_idx] <- predict(model_blup, re.form = NULL)

  dat <- dat |>
    dplyr::group_by(id) |>
    dplyr::mutate(BLUP_x = dplyr::first(stats::na.omit(BLUP_x))) |>
    dplyr::ungroup()

  postVar <- attr(lme4::ranef(model_blup, condVar = TRUE)$id, "postVar")

  dat$SE_BLUP <- sqrt(postVar[1, 1, ])[dat$id]
  dat$V_BLUP_x <- dat$SE_BLUP^2
  dat$SD_BLUP_x <- sqrt(dat$V_BLUP_x)

  # Step 2: Variance modeling for y2 (reference method)
  dat$res_y2 <- dat$y2 - dat$BLUP_x
  dat$abs_res_y2 <- abs(dat$res_y2)

  var_model_y2 <- lm(abs_res_y2 ~ BLUP_x, data = dat)
  theta2_0e <- coef(var_model_y2)[1]
  theta2_1e <- coef(var_model_y2)[2]
  vcov2 <- sandwich::vcovHC(var_model_y2, type = "HC1")

  Vtheta2_1e <- vcov2[2, 2]
  Vtheta2_0e <- vcov2[1, 1]
  COVtheta2e <- vcov2[2, 1]

  dat$fit_abs_res_y2 <- predict(var_model_y2, newdata = dat)
  dat$sig_res_y2 <- dat$fit_abs_res_y2 * sqrt(pi / 2)
  dat$sig2_res_y2 <- dat$sig_res_y2^2

  # Step 3: Bias estimation (differential and proportional)
  bias_model <- lm(y1 ~ BLUP_x, data = dat)
  differential_bias <- coef(bias_model)[1]
  proportional_bias <- coef(bias_model)[2]
  vcov_bias <- sandwich::vcovHC(bias_model, type = "HC1")

  ci_bias <- lmtest::coefci(bias_model, vcov = vcov_bias, level = 0.95)

  message(
    "diff_bias=",
    differential_bias,
    ", 95%CI=[",
    ci_bias[1, 1],
    ";",
    ci_bias[1, 2],
    "]\n"
  )
  message(
    "prop_bias=",
    proportional_bias,
    ", 95%CI=[",
    ci_bias[2, 1],
    ";",
    ci_bias[2, 2],
    "]\n\n"
  )

  Vproportional_bias <- vcov_bias[2, 2]
  Vdifferential_bias <- vcov_bias[1, 1]
  COVbias <- vcov_bias[2, 1]

  # Step 4: Variance modeling for y1 (new method)
  dat$res_y1 <- NA_real_
  dat$res_y1[!is.na(dat$y1)] <- residuals(bias_model)
  dat$abs_res_y1 <- abs(dat$res_y1)

  var_model_y1 <- lm(abs_res_y1 ~ BLUP_x, data = dat)
  theta1_0e <- coef(var_model_y1)[1]
  theta1_1e <- coef(var_model_y1)[2]
  vcov1 <- sandwich::vcovHC(var_model_y1, type = "HC1")

  Vtheta1_1e = vcov1[2, 2]
  Vtheta1_0e = vcov1[1, 1]
  COVtheta1e = vcov1[2, 1]

  dat$fit_abs_res_y1 <- predict(var_model_y1, newdata = dat)
  dat$sig_res_y1 <- dat$fit_abs_res_y1 * sqrt(pi / 2)
  dat$sig2_res_y1 <- dat$sig_res_y1^2

  # Compute overall_agreement
  if (slope == 0) {
    CTLlo <- -intercept
    CTLup <- intercept
  } else {
    CTLlo <- -intercept - slope * dat$BLUP_x
    CTLup <- intercept + slope * dat$BLUP_x
  }

  # Calculate differences
  difference <- dat$y1 - dat$y2

  # Classify points as within or outside limits
  within_limits <- ifelse(
    !is.na(dat$y1) & !is.na(dat$y2),
    difference > CTLlo & difference < CTLup,
    NA
  )

  agreement_ci <- binom::binom.confint(
    x = sum(within_limits, na.rm = TRUE),
    n = sum(!is.na(within_limits)),
    methods = "ac", # Agresti-Coull
    conf.level = 0.95
  )

  overall_agreement <- round(agreement_ci$mean, 3)
  overall_agreement_lo <- clamp(
    round(agreement_ci$lower, 3),
    lo_v = 0.0,
    up_v = 1.0
  )
  overall_agreement_up <- clamp(
    round(agreement_ci$upper, 3),
    lo_v = 0.0,
    up_v = 1.0
  )

  if (tlplot) {
    plot_tolerance_limits(
      BLUP_x = dat$BLUP_x,
      difference = difference,
      CTLlo = CTLlo,
      CTLup = CTLup,
      intercept = intercept,
      slope = slope,
      within_limits = within_limits,
      display = TRUE,
      export_pdf = plots_to_file,
      plot_path = outputs_dir,
      horizontal_ticks = horizontal_ticks,
      vertical_ticks = vertical_ticks,
      font_size = font_size
    )
  }

  agreement <- NULL
  lo_agreement_ptwise <- NULL
  up_agreement_ptwise <- NULL
  lo_agreement_simult <- NULL
  up_agreement_simult <- NULL

  if (cpaplot) {
    message("Number of simulations used for CPA plot is set to ", nbsimul, "\n")

    cond_prob_agreement_results <- plot_condProb_agreement(
      idvar = dat$id,
      BLUP_x = dat$BLUP_x,
      V_BLUP_x = dat$V_BLUP_x,
      SD_BLUP_x = dat$SD_BLUP_x,
      theta2_1e = theta2_1e,
      theta2_0e = theta2_0e,
      Vtheta2_1e = Vtheta2_1e,
      Vtheta2_0e = Vtheta2_0e,
      COVtheta2e = COVtheta2e,
      sig2_res_y2 = dat$sig2_res_y2,
      differential_bias = differential_bias,
      proportional_bias = proportional_bias,
      Vproportional_bias = Vproportional_bias,
      Vdifferential_bias = Vdifferential_bias,
      COVbias = COVbias,
      theta1_1e = theta1_1e,
      theta1_0e = theta1_0e,
      Vtheta1_1e = Vtheta1_1e,
      Vtheta1_0e = Vtheta1_0e,
      COVtheta1e = COVtheta1e,
      sig2_res_y1 = dat$sig2_res_y1,
      CTLlo = CTLlo,
      CTLup = CTLup,
      intercept = intercept,
      slope = slope,
      nbsimul = nbsimul,
      overall_agreement = overall_agreement,
      overall_agreement_lo = overall_agreement_lo,
      overall_agreement_up = overall_agreement_up,
      pointwise_ci = pointwise,
      simultaneous_ci = simultaneous,
      display = TRUE,
      export_pdf = plots_to_file,
      plot_path = outputs_dir,
      horizontal_ticks = horizontal_ticks,
      font_size = font_size
    )

    agreement <- cond_prob_agreement_results$Agreement
    ci_bounds <- cond_prob_agreement_results$ci_bounds
    ci_type <- cond_prob_agreement_results$ci_type

    if (ci_type == 0) {
      # Both pointwise and simultaneous
      lo_agreement_ptwise <- ci_bounds$lo_Agreement
      up_agreement_ptwise <- ci_bounds$up_Agreement
      lo_agreement_simult <- ci_bounds$lo_Agreement_sim
      up_agreement_simult <- ci_bounds$up_Agreement_sim
    } else if (ci_type == 1) {
      # Pointwise only
      lo_agreement_ptwise <- ci_bounds$lo_Agreement
      up_agreement_ptwise <- ci_bounds$up_Agreement
    } else if (ci_type == 2) {
      # Simultaneous only
      lo_agreement_simult <- ci_bounds$lo_Agreement_sim
      up_agreement_simult <- ci_bounds$up_Agreement_sim
    }
  }

  # Save to results to file if requested
  if (cpaplot) {
    dat$agreement <- agreement
    dat$lo_agreement_ptwise <- lo_agreement_ptwise
    dat$up_agreement_ptwise <- up_agreement_ptwise
    dat$lo_agreement_simult <- lo_agreement_simult
    dat$up_agreement_simult <- up_agreement_simult

    dataset <- dat |>
      dplyr::select(
        id = id,
        t = t,
        y1 = y1,
        y2 = y2,
        BLUP_x = BLUP_x,
        agreement = agreement,
        lo_agreement_ptwise = lo_agreement_ptwise,
        up_agreement_ptwise = up_agreement_ptwise,
        lo_agreement_simult = lo_agreement_simult,
        up_agreement_simult = up_agreement_simult
      )
  } else {
    dataset <- dat |>
      dplyr::select(
        id = id,
        t = t,
        y1 = y1,
        y2 = y2,
        BLUP_x = BLUP_x
      )
  }

  overall_agreement_data <- list(
    overall_agreement = overall_agreement,
    overall_agreement_lo = overall_agreement_lo,
    overall_agreement_up = overall_agreement_up
  )

  results_data = list(
    data = dataset,
    overall_agreement = overall_agreement_data
  )

  ctl_results <- results_data

  if (results_to_file) {
    file_path <- file.path(outputs_dir, "ctl_results.rda")
    save(ctl_results, file = file_path)
    message("Results saved to ", normalizePath(file_path))
  }

  return(invisible(ctl_results))
}
